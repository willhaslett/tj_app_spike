export interface HelpData {
    contact_us_url: string;
    knowledge_base_url: string;
}
