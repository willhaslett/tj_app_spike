export interface TaxJurisdictionTaxCollectionData {
    jurisdiction_id: string;
    tax_collected: number|null;
    currency_code: string;
}
