export const apiDateFormat = 'YYYY-MM-DD'
