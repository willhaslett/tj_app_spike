import AD from "./flags/AD.svg";
import AE from "./flags/AE.svg";
import AF from "./flags/AF.svg";
import AG from "./flags/AG.svg";
import AI from "./flags/AI.svg";
import AL from "./flags/AL.svg";
import AM from "./flags/AM.svg";
import AO from "./flags/AO.svg";
import AR from "./flags/AR.svg";
import AS from "./flags/AS.svg";
import AT from "./flags/AT.svg";
import AU from "./flags/AU.svg";
import AW from "./flags/AW.svg";
import AZ from "./flags/AZ.svg";
import BA from "./flags/BA.svg";
import BB from "./flags/BB.svg";
import BD from "./flags/BD.svg";
import BE from "./flags/BE.svg";
import BF from "./flags/BF.svg";
import BG from "./flags/BG.svg";
import BH from "./flags/BH.svg";
import BI from "./flags/BI.svg";
import BJ from "./flags/BJ.svg";
import BM from "./flags/BM.svg";
import BN from "./flags/BN.svg";
import BO from "./flags/BO.svg";
import BQ from "./flags/BQ.svg";
import BR from "./flags/BR.svg";
import BS from "./flags/BS.svg";
import BT from "./flags/BT.svg";
import BW from "./flags/BW.svg";
import BY from "./flags/BY.svg";
import BZ from "./flags/BZ.svg";
import CA from "./flags/CA.svg";
import CC from "./flags/CC.svg";
import CD from "./flags/CD.svg";
import CF from "./flags/CF.svg";
import CG from "./flags/CG.svg";
import CH from "./flags/CH.svg";
import CI from "./flags/CI.svg";
import CK from "./flags/CK.svg";
import CL from "./flags/CL.svg";
import CM from "./flags/CM.svg";
import CN from "./flags/CN.svg";
import CO from "./flags/CO.svg";
import CR from "./flags/CR.svg";
import CU from "./flags/CU.svg";
import CW from "./flags/CW.svg";
import CX from "./flags/CX.svg";
import CY from "./flags/CY.svg";
import CZ from "./flags/CZ.svg";
import DE from "./flags/DE.svg";
import DJ from "./flags/DJ.svg";
import DK from "./flags/DK.svg";
import DM from "./flags/DM.svg";
import DO from "./flags/DO.svg";
import DZ from "./flags/DZ.svg";
import EC from "./flags/EC.svg";
import EE from "./flags/EE.svg";
import EG from "./flags/EG.svg";
import EH from "./flags/EH.svg";
import EN from "./flags/EN.svg";
import ES from "./flags/ES.svg";
import ET from "./flags/ET.svg";
import EU from "./flags/EU.svg";
import FI from "./flags/FI.svg";
import FJ from "./flags/FJ.svg";
import FK from "./flags/FK.svg";
import FM from "./flags/FM.svg";
import FO from "./flags/FO.svg";
import FR from "./flags/FR.svg";
import GA from "./flags/GA.svg";
import GB from "./flags/GB.svg";
import GD from "./flags/GD.svg";
import GE from "./flags/GE.svg";
import GF from "./flags/GF.svg";
import GG from "./flags/GG.svg";
import GH from "./flags/GH.svg";
import GI from "./flags/GI.svg";
import GL from "./flags/GL.svg";
import GM from "./flags/GM.svg";
import GN from "./flags/GN.svg";
import GP from "./flags/GP.svg";
import GQ from "./flags/GQ.svg";
import GR from "./flags/GR.svg";
import GT from "./flags/GT.svg";
import GU from "./flags/GU.svg";
import GW from "./flags/GW.svg";
import GY from "./flags/GY.svg";
import HK from "./flags/HK.svg";
import HM from "./flags/HM.svg";
import HN from "./flags/HN.svg";
import HR from "./flags/HR.svg";
import HT from "./flags/HT.svg";
import HU from "./flags/HU.svg";
import IC from "./flags/IC.svg";
import ID from "./flags/ID.svg";
import IE from "./flags/IE.svg";
import IL from "./flags/IL.svg";
import IM from "./flags/IM.svg";
import IN from "./flags/IN.svg";
import IO from "./flags/IO.svg";
import IQ from "./flags/IQ.svg";
import IR from "./flags/IR.svg";
import IS from "./flags/IS.svg";
import IT from "./flags/IT.svg";
import JE from "./flags/JE.svg";
import JM from "./flags/JM.svg";
import JO from "./flags/JO.svg";
import JP from "./flags/JP.svg";
import KE from "./flags/KE.svg";
import KG from "./flags/KG.svg";
import KH from "./flags/KH.svg";
import KI from "./flags/KI.svg";
import KM from "./flags/KM.svg";
import KN from "./flags/KN.svg";
import KR from "./flags/KR.svg";
import KW from "./flags/KW.svg";
import KY from "./flags/KY.svg";
import KZ from "./flags/KZ.svg";
import LA from "./flags/LA.svg";
import LB from "./flags/LB.svg";
import LC from "./flags/LC.svg";
import LI from "./flags/LI.svg";
import LK from "./flags/LK.svg";
import LR from "./flags/LR.svg";
import LS from "./flags/LS.svg";
import LT from "./flags/LT.svg";
import LU from "./flags/LU.svg";
import LV from "./flags/LV.svg";
import LY from "./flags/LY.svg";
import MA from "./flags/MA.svg";
import MC from "./flags/MC.svg";
import MD from "./flags/MD.svg";
import ME from "./flags/ME.svg";
import MG from "./flags/MG.svg";
import MH from "./flags/MH.svg";
import MK from "./flags/MK.svg";
import ML from "./flags/ML.svg";
import MM from "./flags/MM.svg";
import MO from "./flags/MO.svg";
import MP from "./flags/MP.svg";
import MQ from "./flags/MQ.svg";
import MR from "./flags/MR.svg";
import MS from "./flags/MS.svg";
import MT from "./flags/MT.svg";
import MU from "./flags/MU.svg";
import MV from "./flags/MV.svg";
import MW from "./flags/MW.svg";
import MX from "./flags/MX.svg";
import MY from "./flags/MY.svg";
import MZ from "./flags/MZ.svg";
import NA from "./flags/NA.svg";
import NC from "./flags/NC.svg";
import NE from "./flags/NE.svg";
import NF from "./flags/NF.svg";
import NG from "./flags/NG.svg";
import NI from "./flags/NI.svg";
import NL from "./flags/NL.svg";
import NO from "./flags/NO.svg";
import NP from "./flags/NP.svg";
import NR from "./flags/NR.svg";
import NU from "./flags/NU.svg";
import NZ from "./flags/NZ.svg";
import OM from "./flags/OM.svg";
import PA from "./flags/PA.svg";
import PE from "./flags/PE.svg";
import PF from "./flags/PF.svg";
import PG from "./flags/PG.svg";
import PH from "./flags/PH.svg";
import PK from "./flags/PK.svg";
import PL from "./flags/PL.svg";
import PM from "./flags/PM.svg";
import PN from "./flags/PN.svg";
import PS from "./flags/PS.svg";
import PT from "./flags/PT.svg";
import PW from "./flags/PW.svg";
import PY from "./flags/PY.svg";
import QA from "./flags/QA.svg";
import RE from "./flags/RE.svg";
import RO from "./flags/RO.svg";
import RS from "./flags/RS.svg";
import RU from "./flags/RU.svg";
import RW from "./flags/RW.svg";
import SA from "./flags/SA.svg";
import SB from "./flags/SB.svg";
import SC from "./flags/SC.svg";
import SD from "./flags/SD.svg";
import SE from "./flags/SE.svg";
import SG from "./flags/SG.svg";
import SH from "./flags/SH.svg";
import SI from "./flags/SI.svg";
import SJ from "./flags/SJ.svg";
import SK from "./flags/SK.svg";
import SL from "./flags/SL.svg";
import SN from "./flags/SN.svg";
import SO from "./flags/SO.svg";
import SR from "./flags/SR.svg";
import SS from "./flags/SS.svg";
import ST from "./flags/ST.svg";
import SV from "./flags/SV.svg";
import SX from "./flags/SX.svg";
import SZ from "./flags/SZ.svg";
import TC from "./flags/TC.svg";
import TD from "./flags/TD.svg";
import TF from "./flags/TF.svg";
import TH from "./flags/TH.svg";
import TJ from "./flags/TJ.svg";
import TK from "./flags/TK.svg";
import TL from "./flags/TL.svg";
import TM from "./flags/TM.svg";
import TN from "./flags/TN.svg";
import TO from "./flags/TO.svg";
import TR from "./flags/TR.svg";
import TT from "./flags/TT.svg";
import TV from "./flags/TV.svg";
import TW from "./flags/TW.svg";
import TZ from "./flags/TZ.svg";
import UA from "./flags/UA.svg";
import UG from "./flags/UG.svg";
import US from "./flags/US.svg";
import UV from "./flags/UV.svg";
import UZ from "./flags/UZ.svg";
import VA from "./flags/VA.svg";
import VE from "./flags/VE.svg";
import VG from "./flags/VG.svg";
import VN from "./flags/VN.svg";
import VU from "./flags/VU.svg";
import WF from "./flags/WF.svg";
import WS from "./flags/WS.svg";
import XI from "./flags/XI.svg";
import XM from "./flags/XM.svg";
import YE from "./flags/YE.svg";
import YT from "./flags/YT.svg";
import YU from "./flags/YU.svg";
import ZA from "./flags/ZA.svg";
import ZM from "./flags/ZM.svg";
import ZW from "./flags/ZW.svg";

// Create a type for the flagSvgImages object
type FlagSvgImages = {
    [key in string]: string;
};

export const flagSvgImages: FlagSvgImages = {
    AD,
    AE,
    AF,
    AG,
    AI,
    AL,
    AM,
    AO,
    AR,
    AS,
    AT,
    AU,
    AW,
    AZ,
    BA,
    BB,
    BD,
    BE,
    BF,
    BG,
    BH,
    BI,
    BJ,
    BM,
    BN,
    BO,
    BQ,
    BR,
    BS,
    BT,
    BW,
    BY,
    BZ,
    CA,
    CC,
    CD,
    CF,
    CG,
    CH,
    CI,
    CK,
    CL,
    CM,
    CN,
    CO,
    CR,
    CU,
    CW,
    CX,
    CY,
    CZ,
    DE,
    DJ,
    DK,
    DM,
    DO,
    DZ,
    EC,
    EE,
    EG,
    EH,
    EN,
    ES,
    ET,
    EU,
    FI,
    FJ,
    FK,
    FM,
    FO,
    FR,
    GA,
    GB,
    GD,
    GE,
    GF,
    GG,
    GH,
    GI,
    GL,
    GM,
    GN,
    GP,
    GQ,
    GR,
    GT,
    GU,
    GW,
    GY,
    HK,
    HM,
    HN,
    HR,
    HT,
    HU,
    IC,
    ID,
    IE,
    IL,
    IM,
    IN,
    IO,
    IQ,
    IR,
    IS,
    IT,
    JE,
    JM,
    JO,
    JP,
    KE,
    KG,
    KH,
    KI,
    KM,
    KN,
    KR,
    KW,
    KY,
    KZ,
    LA,
    LB,
    LC,
    LI,
    LK,
    LR,
    LS,
    LT,
    LU,
    LV,
    LY,
    MA,
    MC,
    MD,
    ME,
    MG,
    MH,
    MK,
    ML,
    MM,
    MO,
    MP,
    MQ,
    MR,
    MS,
    MT,
    MU,
    MV,
    MW,
    MX,
    MY,
    MZ,
    NA,
    NC,
    NE,
    NF,
    NG,
    NI,
    NL,
    NO,
    NP,
    NR,
    NU,
    NZ,
    OM,
    PA,
    PE,
    PF,
    PG,
    PH,
    PK,
    PL,
    PM,
    PN,
    PS,
    PT,
    PW,
    PY,
    QA,
    RE,
    RO,
    RS,
    RU,
    RW,
    SA,
    SB,
    SC,
    SD,
    SE,
    SG,
    SH,
    SI,
    SJ,
    SK,
    SL,
    SN,
    SO,
    SR,
    SS,
    ST,
    SV,
    SX,
    SZ,
    TC,
    TD,
    TF,
    TH,
    TJ,
    TK,
    TL,
    TM,
    TN,
    TO,
    TR,
    TT,
    TV,
    TW,
    TZ,
    UA,
    UG,
    US,
    UV,
    UZ,
    VA,
    VE,
    VG,
    VN,
    VU,
    WF,
    WS,
    XI,
    XM,
    YE,
    YT,
    YU,
    ZA,
    ZM,
    ZW
};
