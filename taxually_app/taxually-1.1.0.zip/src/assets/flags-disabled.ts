import AD from "./flags-disabled/AD_disabled.svg";
import AE from "./flags-disabled/AE_disabled.svg";
import AF from "./flags-disabled/AF_disabled.svg";
import AG from "./flags-disabled/AG_disabled.svg";
import AI from "./flags-disabled/AI_disabled.svg";
import AL from "./flags-disabled/AL_disabled.svg";
import AM from "./flags-disabled/AM_disabled.svg";
import AO from "./flags-disabled/AO_disabled.svg";
import AR from "./flags-disabled/AR_disabled.svg";
import AS from "./flags-disabled/AS_disabled.svg";
import AT from "./flags-disabled/AT_disabled.svg";
import AU from "./flags-disabled/AU_disabled.svg";
import AW from "./flags-disabled/AW_disabled.svg";
import AZ from "./flags-disabled/AZ_disabled.svg";
import BA from "./flags-disabled/BA_disabled.svg";
import BB from "./flags-disabled/BB_disabled.svg";
import BD from "./flags-disabled/BD_disabled.svg";
import BE from "./flags-disabled/BE_disabled.svg";
import BF from "./flags-disabled/BF_disabled.svg";
import BG from "./flags-disabled/BG_disabled.svg";
import BH from "./flags-disabled/BH_disabled.svg";
import BI from "./flags-disabled/BI_disabled.svg";
import BJ from "./flags-disabled/BJ_disabled.svg";
import BM from "./flags-disabled/BM_disabled.svg";
import BN from "./flags-disabled/BN_disabled.svg";
import BO from "./flags-disabled/BO_disabled.svg";
import BQ from "./flags-disabled/BQ_disabled.svg";
import BR from "./flags-disabled/BR_disabled.svg";
import BS from "./flags-disabled/BS_disabled.svg";
import BT from "./flags-disabled/BT_disabled.svg";
import BW from "./flags-disabled/BW_disabled.svg";
import BY from "./flags-disabled/BY_disabled.svg";
import BZ from "./flags-disabled/BZ_disabled.svg";
import CA from "./flags-disabled/CA_disabled.svg";
import CC from "./flags-disabled/CC_disabled.svg";
import CD from "./flags-disabled/CD_disabled.svg";
import CF from "./flags-disabled/CF_disabled.svg";
import CG from "./flags-disabled/CG_disabled.svg";
import CH from "./flags-disabled/CH_disabled.svg";
import CI from "./flags-disabled/CI_disabled.svg";
import CK from "./flags-disabled/CK_disabled.svg";
import CL from "./flags-disabled/CL_disabled.svg";
import CM from "./flags-disabled/CM_disabled.svg";
import CN from "./flags-disabled/CN_disabled.svg";
import CO from "./flags-disabled/CO_disabled.svg";
import CR from "./flags-disabled/CR_disabled.svg";
import CU from "./flags-disabled/CU_disabled.svg";
import CW from "./flags-disabled/CW_disabled.svg";
import CX from "./flags-disabled/CX_disabled.svg";
import CY from "./flags-disabled/CY_disabled.svg";
import CZ from "./flags-disabled/CZ_disabled.svg";
import DE from "./flags-disabled/DE_disabled.svg";
import DJ from "./flags-disabled/DJ_disabled.svg";
import DK from "./flags-disabled/DK_disabled.svg";
import DM from "./flags-disabled/DM_disabled.svg";
import DO from "./flags-disabled/DO_disabled.svg";
import DZ from "./flags-disabled/DZ_disabled.svg";
import EC from "./flags-disabled/EC_disabled.svg";
import EE from "./flags-disabled/EE_disabled.svg";
import EG from "./flags-disabled/EG_disabled.svg";
import EH from "./flags-disabled/EH_disabled.svg";
import EN from "./flags-disabled/EN_disabled.svg";
import ES from "./flags-disabled/ES_disabled.svg";
import ET from "./flags-disabled/ET_disabled.svg";
import EU from "./flags-disabled/EU_disabled.svg";
import FI from "./flags-disabled/FI_disabled.svg";
import FJ from "./flags-disabled/FJ_disabled.svg";
import FK from "./flags-disabled/FK_disabled.svg";
import FM from "./flags-disabled/FM_disabled.svg";
import FO from "./flags-disabled/FO_disabled.svg";
import FR from "./flags-disabled/FR_disabled.svg";
import GA from "./flags-disabled/GA_disabled.svg";
import GB from "./flags-disabled/GB_disabled.svg";
import GD from "./flags-disabled/GD_disabled.svg";
import GE from "./flags-disabled/GE_disabled.svg";
import GF from "./flags-disabled/GF_disabled.svg";
import GG from "./flags-disabled/GG_disabled.svg";
import GH from "./flags-disabled/GH_disabled.svg";
import GI from "./flags-disabled/GI_disabled.svg";
import GL from "./flags-disabled/GL_disabled.svg";
import GM from "./flags-disabled/GM_disabled.svg";
import GN from "./flags-disabled/GN_disabled.svg";
import GP from "./flags-disabled/GP_disabled.svg";
import GQ from "./flags-disabled/GQ_disabled.svg";
import GR from "./flags-disabled/GR_disabled.svg";
import GT from "./flags-disabled/GT_disabled.svg";
import GU from "./flags-disabled/GU_disabled.svg";
import GW from "./flags-disabled/GW_disabled.svg";
import GY from "./flags-disabled/GY_disabled.svg";
import HK from "./flags-disabled/HK_disabled.svg";
import HM from "./flags-disabled/HM_disabled.svg";
import HN from "./flags-disabled/HN_disabled.svg";
import HR from "./flags-disabled/HR_disabled.svg";
import HT from "./flags-disabled/HT_disabled.svg";
import HU from "./flags-disabled/HU_disabled.svg";
import IC from "./flags-disabled/IC_disabled.svg";
import ID from "./flags-disabled/ID_disabled.svg";
import IE from "./flags-disabled/IE_disabled.svg";
import IL from "./flags-disabled/IL_disabled.svg";
import IM from "./flags-disabled/IM_disabled.svg";
import IN from "./flags-disabled/IN_disabled.svg";
import IO from "./flags-disabled/IO_disabled.svg";
import IQ from "./flags-disabled/IQ_disabled.svg";
import IR from "./flags-disabled/IR_disabled.svg";
import IS from "./flags-disabled/IS_disabled.svg";
import IT from "./flags-disabled/IT_disabled.svg";
import JE from "./flags-disabled/JE_disabled.svg";
import JM from "./flags-disabled/JM_disabled.svg";
import JO from "./flags-disabled/JO_disabled.svg";
import JP from "./flags-disabled/JP_disabled.svg";
import KE from "./flags-disabled/KE_disabled.svg";
import KG from "./flags-disabled/KG_disabled.svg";
import KH from "./flags-disabled/KH_disabled.svg";
import KI from "./flags-disabled/KI_disabled.svg";
import KM from "./flags-disabled/KM_disabled.svg";
import KN from "./flags-disabled/KN_disabled.svg";
import KR from "./flags-disabled/KR_disabled.svg";
import KW from "./flags-disabled/KW_disabled.svg";
import KY from "./flags-disabled/KY_disabled.svg";
import KZ from "./flags-disabled/KZ_disabled.svg";
import LA from "./flags-disabled/LA_disabled.svg";
import LB from "./flags-disabled/LB_disabled.svg";
import LC from "./flags-disabled/LC_disabled.svg";
import LI from "./flags-disabled/LI_disabled.svg";
import LK from "./flags-disabled/LK_disabled.svg";
import LR from "./flags-disabled/LR_disabled.svg";
import LS from "./flags-disabled/LS_disabled.svg";
import LT from "./flags-disabled/LT_disabled.svg";
import LU from "./flags-disabled/LU_disabled.svg";
import LV from "./flags-disabled/LV_disabled.svg";
import LY from "./flags-disabled/LY_disabled.svg";
import MA from "./flags-disabled/MA_disabled.svg";
import MC from "./flags-disabled/MC_disabled.svg";
import MD from "./flags-disabled/MD_disabled.svg";
import ME from "./flags-disabled/ME_disabled.svg";
import MG from "./flags-disabled/MG_disabled.svg";
import MH from "./flags-disabled/MH_disabled.svg";
import MK from "./flags-disabled/MK_disabled.svg";
import ML from "./flags-disabled/ML_disabled.svg";
import MM from "./flags-disabled/MM_disabled.svg";
import MO from "./flags-disabled/MO_disabled.svg";
import MP from "./flags-disabled/MP_disabled.svg";
import MQ from "./flags-disabled/MQ_disabled.svg";
import MR from "./flags-disabled/MR_disabled.svg";
import MS from "./flags-disabled/MS_disabled.svg";
import MT from "./flags-disabled/MT_disabled.svg";
import MU from "./flags-disabled/MU_disabled.svg";
import MV from "./flags-disabled/MV_disabled.svg";
import MW from "./flags-disabled/MW_disabled.svg";
import MX from "./flags-disabled/MX_disabled.svg";
import MY from "./flags-disabled/MY_disabled.svg";
import MZ from "./flags-disabled/MZ_disabled.svg";
import NA from "./flags-disabled/NA_disabled.svg";
import NC from "./flags-disabled/NC_disabled.svg";
import NE from "./flags-disabled/NE_disabled.svg";
import NF from "./flags-disabled/NF_disabled.svg";
import NG from "./flags-disabled/NG_disabled.svg";
import NI from "./flags-disabled/NI_disabled.svg";
import NL from "./flags-disabled/NL_disabled.svg";
import NO from "./flags-disabled/NO_disabled.svg";
import NP from "./flags-disabled/NP_disabled.svg";
import NR from "./flags-disabled/NR_disabled.svg";
import NU from "./flags-disabled/NU_disabled.svg";
import NZ from "./flags-disabled/NZ_disabled.svg";
import OM from "./flags-disabled/OM_disabled.svg";
import PA from "./flags-disabled/PA_disabled.svg";
import PE from "./flags-disabled/PE_disabled.svg";
import PF from "./flags-disabled/PF_disabled.svg";
import PG from "./flags-disabled/PG_disabled.svg";
import PH from "./flags-disabled/PH_disabled.svg";
import PK from "./flags-disabled/PK_disabled.svg";
import PL from "./flags-disabled/PL_disabled.svg";
import PM from "./flags-disabled/PM_disabled.svg";
import PN from "./flags-disabled/PN_disabled.svg";
import PS from "./flags-disabled/PS_disabled.svg";
import PT from "./flags-disabled/PT_disabled.svg";
import PW from "./flags-disabled/PW_disabled.svg";
import PY from "./flags-disabled/PY_disabled.svg";
import QA from "./flags-disabled/QA_disabled.svg";
import RE from "./flags-disabled/RE_disabled.svg";
import RO from "./flags-disabled/RO_disabled.svg";
import RS from "./flags-disabled/RS_disabled.svg";
import RU from "./flags-disabled/RU_disabled.svg";
import RW from "./flags-disabled/RW_disabled.svg";
import SA from "./flags-disabled/SA_disabled.svg";
import SB from "./flags-disabled/SB_disabled.svg";
import SC from "./flags-disabled/SC_disabled.svg";
import SD from "./flags-disabled/SD_disabled.svg";
import SE from "./flags-disabled/SE_disabled.svg";
import SG from "./flags-disabled/SG_disabled.svg";
import SH from "./flags-disabled/SH_disabled.svg";
import SI from "./flags-disabled/SI_disabled.svg";
import SJ from "./flags-disabled/SJ_disabled.svg";
import SK from "./flags-disabled/SK_disabled.svg";
import SL from "./flags-disabled/SL_disabled.svg";
import SN from "./flags-disabled/SN_disabled.svg";
import SO from "./flags-disabled/SO_disabled.svg";
import SR from "./flags-disabled/SR_disabled.svg";
import SS from "./flags-disabled/SS_disabled.svg";
import ST from "./flags-disabled/ST_disabled.svg";
import SV from "./flags-disabled/SV_disabled.svg";
import SX from "./flags-disabled/SX_disabled.svg";
import SZ from "./flags-disabled/SZ_disabled.svg";
import TC from "./flags-disabled/TC_disabled.svg";
import TD from "./flags-disabled/TD_disabled.svg";
import TF from "./flags-disabled/TF_disabled.svg";
import TH from "./flags-disabled/TH_disabled.svg";
import TJ from "./flags-disabled/TJ_disabled.svg";
import TK from "./flags-disabled/TK_disabled.svg";
import TL from "./flags-disabled/TL_disabled.svg";
import TM from "./flags-disabled/TM_disabled.svg";
import TN from "./flags-disabled/TN_disabled.svg";
import TO from "./flags-disabled/TO_disabled.svg";
import TR from "./flags-disabled/TR_disabled.svg";
import TT from "./flags-disabled/TT_disabled.svg";
import TV from "./flags-disabled/TV_disabled.svg";
import TW from "./flags-disabled/TW_disabled.svg";
import TZ from "./flags-disabled/TZ_disabled.svg";
import UA from "./flags-disabled/UA_disabled.svg";
import UG from "./flags-disabled/UG_disabled.svg";
import US from "./flags-disabled/US_disabled.svg";
import UV from "./flags-disabled/UV_disabled.svg";
import UZ from "./flags-disabled/UZ_disabled.svg";
import VA from "./flags-disabled/VA_disabled.svg";
import VE from "./flags-disabled/VE_disabled.svg";
import VG from "./flags-disabled/VG_disabled.svg";
import VN from "./flags-disabled/VN_disabled.svg";
import VU from "./flags-disabled/VU_disabled.svg";
import WF from "./flags-disabled/WF_disabled.svg";
import WS from "./flags-disabled/WS_disabled.svg";
import XI from "./flags-disabled/XI_disabled.svg";
import XM from "./flags-disabled/XM_disabled.svg";
import YE from "./flags-disabled/YE_disabled.svg";
import YT from "./flags-disabled/YT_disabled.svg";
import YU from "./flags-disabled/YU_disabled.svg";
import ZA from "./flags-disabled/ZA_disabled.svg";
import ZM from "./flags-disabled/ZM_disabled.svg";
import ZW from "./flags-disabled/ZW_disabled.svg";

// Create a type for the flagSvgImages object
type DisabledFlagSvgImages = {
    [key in string]: string;
};

export const disabledFlagSvgImages: DisabledFlagSvgImages = {
    AD,
    AE,
    AF,
    AG,
    AI,
    AL,
    AM,
    AO,
    AR,
    AS,
    AT,
    AU,
    AW,
    AZ,
    BA,
    BB,
    BD,
    BE,
    BF,
    BG,
    BH,
    BI,
    BJ,
    BM,
    BN,
    BO,
    BQ,
    BR,
    BS,
    BT,
    BW,
    BY,
    BZ,
    CA,
    CC,
    CD,
    CF,
    CG,
    CH,
    CI,
    CK,
    CL,
    CM,
    CN,
    CO,
    CR,
    CU,
    CW,
    CX,
    CY,
    CZ,
    DE,
    DJ,
    DK,
    DM,
    DO,
    DZ,
    EC,
    EE,
    EG,
    EH,
    EN,
    ES,
    ET,
    EU,
    FI,
    FJ,
    FK,
    FM,
    FO,
    FR,
    GA,
    GB,
    GD,
    GE,
    GF,
    GG,
    GH,
    GI,
    GL,
    GM,
    GN,
    GP,
    GQ,
    GR,
    GT,
    GU,
    GW,
    GY,
    HK,
    HM,
    HN,
    HR,
    HT,
    HU,
    IC,
    ID,
    IE,
    IL,
    IM,
    IN,
    IO,
    IQ,
    IR,
    IS,
    IT,
    JE,
    JM,
    JO,
    JP,
    KE,
    KG,
    KH,
    KI,
    KM,
    KN,
    KR,
    KW,
    KY,
    KZ,
    LA,
    LB,
    LC,
    LI,
    LK,
    LR,
    LS,
    LT,
    LU,
    LV,
    LY,
    MA,
    MC,
    MD,
    ME,
    MG,
    MH,
    MK,
    ML,
    MM,
    MO,
    MP,
    MQ,
    MR,
    MS,
    MT,
    MU,
    MV,
    MW,
    MX,
    MY,
    MZ,
    NA,
    NC,
    NE,
    NF,
    NG,
    NI,
    NL,
    NO,
    NP,
    NR,
    NU,
    NZ,
    OM,
    PA,
    PE,
    PF,
    PG,
    PH,
    PK,
    PL,
    PM,
    PN,
    PS,
    PT,
    PW,
    PY,
    QA,
    RE,
    RO,
    RS,
    RU,
    RW,
    SA,
    SB,
    SC,
    SD,
    SE,
    SG,
    SH,
    SI,
    SJ,
    SK,
    SL,
    SN,
    SO,
    SR,
    SS,
    ST,
    SV,
    SX,
    SZ,
    TC,
    TD,
    TF,
    TH,
    TJ,
    TK,
    TL,
    TM,
    TN,
    TO,
    TR,
    TT,
    TV,
    TW,
    TZ,
    UA,
    UG,
    US,
    UV,
    UZ,
    VA,
    VE,
    VG,
    VN,
    VU,
    WF,
    WS,
    XI,
    XM,
    YE,
    YT,
    YU,
    ZA,
    ZM,
    ZW
};
